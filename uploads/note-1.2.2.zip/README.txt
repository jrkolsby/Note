
--------------------------------------
Note CMS (Content Management System)
BETA 1.2.0 - 3 November 2013
Copyright James Kolsby 2013
--------------------------------------


------
 BUGS
------

If you encounter any problems with this version of Note, please e-mail
jrkolsby@mac.com with the version number of Note, the internet browser
being used, and specific instructions to replicate the problem.


-------------
 WHAT IS IT?
-------------

Note CMS is a method of quickly and easily updating the content 
of a website without needing to change HTML files. Note is different
from other Content Management Systems as it allows your content to
be updated directly on the page, without the need for any external
interface. This makes the task of updating a website much quicker
and easier.

For more info and other Note releases, check:
http://jmkl.co/note


--------------
 INSTALLATION
--------------

1. Put the "note" folder that contains this text file anywhere in
your server.

        For each page that Note will be allowed to edit:
        ------------------------------------------------

1. Add a link to jQuery within the <head> tag of your website. For
jQuery 1.10.2, that link would look like this:

<script type="text/javascript" src="http://ajax.googleapis.com/ajax/libs/jquery/1.10.2/jquery.min.js"></script>

- Keep in mind that jQuery updates require a change in the src 
attribute of this tag. The latest jQuery build can be found at 
http://jquery.com

2. Add a link to the "note.js" script inside the "note" folder. So,
for example, if the note folder is in the same directory as the page
file, it might look like this:

<script type="text/javascript" src="note/note.js"></script>

- If it is in the parent directory:

<script type="text/javascript" src="../note/note.js"></script>

- If it is in a child directory:

<script type="text/javascript" src="scripts/note/note.js"></script>


---------------
 CONFIGURATION
---------------

1. To create a username and password for all pages associated with
your "note" folder, find "login.php" inside the "note" folder, and
edit the login variables where indicated. If your username were to
be "foo", and your password "bar", you would change "login.php" to
look like:

$user="foo";
$pass="bar";

2. If your domain root is a location that is not the root of your
server, you will have to edit the $domainroot variable. Say, for
example, your server had the following contents:

SERVER ROOT/

  website1/
    home/
    info/
    blog/
    contact/
  storage/
    website2/
      home/
      images/
      videos/
    website3/
    
- If your domain root at http://www.mydomain.com/ was the folder
"website1", you would make the value of $domainroot to "/website1".
In "login.php", this would look like:

$domainroot="/website1";

- If your domain root at http://www.mydomain.com/ was the folder
"website2", you would change the value of $domainroot to
"/storage/website2".In "login.php", this would look like:

$domainroot="/storage/website1";


------------------
 PAGE PREPARATION
------------------

- Note requires that HTML elements give permission to be edited. To
make an element editable by Note, the "note" class must be added
to that element. If editing a simple <h1> tag:

<h1>Lorem Ipsum Dolor</h1>

- This would be changed to:

<h1 class="note">Lorem Ipsum Dolor</h1>

- And now Note can edit this element.

- For compound elements, or elements with editable children, add the
"post" class to the parent element along with the "note" class. Say,
for example, you wanted Note to edit a blog post:

<div class="blogpost">
<img src="http://lorempixel.com/600/400/">
<div class="blogpost-body">
<h1>Post Title</h1>
<h2>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor.</h2>
</div>
</div>

- You would change this to:

<div class="blogpost note post">
<img class="note" src="http://lorempixel.com/600/400/">
<div class="blogpost-body">
<h1 class="note">Post Title</h1>
<h2 class="note">Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor.</h2>
</div>
</div>


-------
 USAGE
-------

1. Press "Control + N" to activate Note on a page. If you are on a Mac,
some browsers are compatible with "Command + N"

2. Yellow Highlight boxes should appear around the editable elements.
Click on one to begin.

3. The note text box is where each editable element's content can be
edited based on what type of element is selected. An image, for 
example, will allow its "src" element to be edited, while an "h1"
element will allow its HTML contents to be edited.

- Compound elements have arrows in their toolbars to allow navigation
through their editable child elements.

- The delete button deletes the selected element on save.

- The copy button inserts a copy of the selected element after itself on
save.

- The upload button gives the option to upload a file to note's "upload"
directory. This can be used to store images, link to files, or do just
about anything else without an FTP client. Files are uploaded on save,
and only one file can be uploaded per save.

4. To save, press "Control + S", or on a Mac "Command + S" will again only
work with certain browsers.

- The page has now been saved. Blocks will be updated by default, but
blocks with delete selected will be deleted, blocks with copy selected
will be copied, and blocks with a file set to upload will upload that
file. Blocks set to execute other methods will not update their content.