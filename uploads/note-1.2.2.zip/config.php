<?php
$user = "username"; //EDIT "username" TO CHANGE YOUR USERNAME
$pass = "password"; //EDIT "password" TO CHANGE YOUR USERNAME
$domainroot = ""; //EDIT THIS LINE TO CHANGE THE DOMAIN ROOT
if(isset($_POST['pass'])){if($_POST['pass']==$pass&&$_POST['user']==$user){print "true";}else{print "false";}}?>